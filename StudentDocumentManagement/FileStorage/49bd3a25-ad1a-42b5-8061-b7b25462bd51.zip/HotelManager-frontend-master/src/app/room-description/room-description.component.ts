import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-room-description',
  standalone: false,
  templateUrl: './room-description.component.html',
  styleUrl: './room-description.component.css'
})
export class RoomDescriptionComponent {
  // room: any;
  // reviews: any[] = [];
  // book: any[] = [];
  // bookingDetails: any = null;
  // isFavorite = false;
  // numberOfRooms = 1;

  // constructor(
  //   private route: ActivatedRoute,
  //   private roomService: DataserviceService
  // ) { }

  // ngOnInit(): void {
  //   const id = Number(this.route.snapshot.paramMap.get('roomTypeId'));
  //   const queryParams = this.route.snapshot.queryParams;

  //   this.roomService.getRoomById(id).subscribe({
  //     next: (data) => {
  //       this.room = {
  //         ...data,
  //         roomType: data.roomTypeName,
  //         imagePaths: data.images || []
  //       };

  //       // ✅ Store booking form values from query
  //       this.bookingDetails = {
  //         checkIn: new Date(queryParams['checkIn']),
  //         checkOut: new Date(queryParams['checkOut']),
  //         adults: Number(queryParams['adults']),
  //         children: Number(queryParams['children']),
  //         availableRooms: Number(queryParams['availableRooms'])
  //       };

  //       this.loadSampleReviews();
  //     },
  //     error: (err) => {
  //       console.error('Failed to load room:', err);
  //     }
  //   });
  // }


  // loadSampleReviews() {
  //   this.reviews = [
  //     {
  //       reviewer: 'Anjali Sharma',
  //       rating: 4,
  //       comment: 'Spacious room with a beautiful view. Staff was very courteous!',
  //       date: '2025-07-15'
  //     },
  //     {
  //       reviewer: 'Rahul Verma',
  //       rating: 5,
  //       comment: 'Excellent stay! Clean and well-maintained. Highly recommended.',
  //       date: '2025-07-10'
  //     },
  //     {
  //       reviewer: 'Meera Nair',
  //       rating: 3,
  //       comment: 'Good location, but room service could be better.',
  //       date: '2025-07-01'
  //     }
  //   ];
  // }

  // toggleFavorite() {
  //   this.isFavorite = !this.isFavorite;
  // }

  // get discountedRate(): number {
  //   const discount = (this.room?.ratePerDay * (this.room?.discountPercentage ?? 0)) / 100;
  //   return this.room?.ratePerDay - discount;
  // }

  // get totalRate(): number {
  //   const subtotal = this.discountedRate * this.numberOfRooms;
  //   const tax = subtotal * (this.room?.taxRate / 100);
  //   return subtotal + tax;
  // }

  // get maxAllowedGuests(): number {
  //   return this.numberOfRooms * (this.room?.maxOccupancy || 0);
  // }
  
  // get totalGuests(): number {
  //   return (this.bookingDetails?.adults || 0) + (this.bookingDetails?.children || 0);
  // }
  
  // get guestOverflow(): boolean {
  //   return this.totalGuests > this.maxAllowedGuests;
  // }
  



  // bookNow() {
  //   const available = this.bookingDetails.availableRooms;
  //   if (this.numberOfRooms > available) {
  //     alert(`Only ${available} room(s) available for your selected dates.`);
  //     return;
  //   }

  //   if (this.totalGuests > this.maxAllowedGuests) {
  //     alert(`Total guests exceed maximum occupancy for ${this.numberOfRooms} room(s). Allowed: ${this.maxAllowedGuests}`);
  //     return;
  //   }

  //   const payload = {
  //     checkIn: this.bookingDetails.checkIn,
  //     checkOut: this.bookingDetails.checkOut,
  //     adults: this.bookingDetails.adults,
  //     children: this.bookingDetails.children,
  //     userId: localStorage.getItem('userId'),
  //     roomTypeId: this.room.roomTypeId,
  //     requestedRooms: this.numberOfRooms
  //   };

  //   this.roomService.bookRoom(payload).subscribe({
  //     next: (res) => {
  //       this.bookingDetails = {
  //         ...this.bookingDetails, // keep dates, guests
  //         bookingId: res.bookingId,
  //         bookingDate: new Date(),
  //         roomCount: res.roomCount,
  //         baseAmount: res.baseAmount,
  //         discountedAmount: res.discountedAmount,
  //         taxAmount: res.taxAmount,
  //         finalAmount: res.finalAmount
  //       };
  //        // ✅ Clear saved filters from localStorage after successful booking
  //   localStorage.removeItem('roomSearchFilter');
  //     },
  //     error: (err) => {
  //       alert('Booking failed. Please try again later.');
  //       console.error(err);
  //     }
  //   });
  // }


}
