import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../environment/environment';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
  private baseUrl = environment.apiUrl;
  constructor(private http: HttpClient) { }

  authenticate(request: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/Account/Authenticate`, request, {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  //register users
  register(request: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/Account/RegisterUser`, request, {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  registerAdmin(request: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/Account/RegisterAdmin`, request, {
      headers: { 'Content-Type': 'application/json' }
    });
  }

  getAvailableRooms(filter: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/Room/SearchAvailableRooms`, filter
    );
  }

  getRoomById(roomTypeId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/Room/GetRoomById${roomTypeId}`);
  }

  bookRoom(payload: any) {
    return this.http.post<any>(`${this.baseUrl}/Booking/Book`, payload);
  }

  addRoomType(roomTypeData: any) {
    return this.http.post(`${this.baseUrl}/Room/AddRoomType`, roomTypeData);
  }

  updateRoomType(roomTypeId: number, body: any) {
    return this.http.put(`${this.baseUrl}/Room/UpdateRoomType/${roomTypeId}`, body);
  }

  addRoom(roomData: any) {
    return this.http.post(`${this.baseUrl}/Room/AddRoom`, roomData);
  }

  updateRoomStatus(roomId: number, statusName: string): Observable<string> {
    const body = { statusName };
    return this.http.put<string>(`${this.baseUrl}/Room/UpdateRoom/${roomId}`, body, {});
  }

  deleteRoom(roomId: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/Room/DeleteRoom/${roomId}`);
  }


  getAllRooms(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/Room/GetAllRooms`);
  }


  getRoomTypes() {
    return this.http.get<any[]>(`${this.baseUrl}/Room/GetAllRoomTypes`);
  }

  getAmenities() {
    return this.http.get<any[]>(`${this.baseUrl}/List/GetAllAmenity`);
  }

  //reviews
  getRoomTypeRatings(roomTypeId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/Rating/roomtype/${roomTypeId}`);
  }
  
  //star 
  getRoomTypeAverageRating(roomTypeId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/Rating/AverageRating/${roomTypeId}`);
  }
  

  getRoomStatuses() {
    return this.http.get<any[]>(`${this.baseUrl}/List/GetAllRoomStatus`);
  }

  getAllBookings(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/Booking/GetAllBookings`);
  }

  getAllBookingsBySearch(params: any): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/Booking/GetAllBookingsBySearch`, {
      params: params
    });
  }
  
  cancelBooking(bookingId: number, isAdmin: boolean = false) {
    return this.http.put<any>(`${this.baseUrl}/Booking/Cancel/${bookingId}?isAdmin=${isAdmin}`, {});
  }
  

  checkIn(bookingId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/Booking/CheckIn/${bookingId}`, {});
  }


  previewAmount(bookingId: number) {
    return this.http.get<any>(`${this.baseUrl}/Booking/PreviewAmount/${bookingId}`);
  }



  checkOut(bookingId: number, isPaymentDone: boolean): Observable<any> {
    return this.http.put(`${this.baseUrl}/Booking/CheckOut/${bookingId}`, {
      isPaymentDone
    });
  }



  getBookingHistory(userId: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/User/UserBookingHistory/${userId}`);
  }

  submitRating(data: any) {
    return this.http.post(`${this.baseUrl}/Rating/rate`, data);
  }

  getUserProfile(userId: string): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/User/Profile/${userId}`);
  }

  updateUserProfile(profile: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/User/UpdateProfile`, profile);
  }

  addRole(role: { roleName: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/Administrative/CreateRole`, role);
  }

  getRoles(): Observable<any> {
    return this.http.get(`${this.baseUrl}/Administrative/ListRoles`);
  }

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/Account/GetUsers`);
  }

  assignUserRole(userId: string, roles: { roleName: string, isSelected: boolean }[]) {
    return this.http.post(`${this.baseUrl}/Administrative/AssignRoles/${userId}`, roles);
  }

  getUserRoles() {
    return this.http.get<{ response: any[] }>(`${this.baseUrl}/Administrative/UserRoles`); //  [{ userName, roleName }]
  }

  getAdminDashboard() {
    return this.http.get<any>(`${this.baseUrl}/List/AdminDashboard`);
  }





}
