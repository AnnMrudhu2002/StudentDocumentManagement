import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-roomlist',
  standalone: false,
  templateUrl: './roomlist.component.html',
  styleUrl: './roomlist.component.css'
})
export class RoomlistComponent {
  roomTypes: any[] = [];

  constructor(private dataService: DataserviceService, private router: Router) {}

  ngOnInit(): void {
    this.dataService.getRoomTypes().subscribe({
      next: (data) => this.roomTypes = data,
      error: (err) => console.error('Error fetching room types:', err)
    });
  }

  bookNow() {
    this.router.navigate(['/login']);
  }
}
