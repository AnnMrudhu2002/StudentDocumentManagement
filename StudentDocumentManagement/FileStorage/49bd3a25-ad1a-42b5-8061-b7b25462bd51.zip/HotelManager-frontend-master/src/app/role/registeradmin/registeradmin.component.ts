import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-registeradmin',
  standalone: false,
  templateUrl: './registeradmin.component.html',
  styleUrl: './registeradmin.component.css'
})
export class RegisteradminComponent {
  UserName: string = '';
  Password: string = '';
  ConfirmPassword: string = '';
  loading: boolean = false;
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;
  

  constructor(private dataService: DataserviceService, private toastr: ToastrService) { }

 
togglePasswordVisibility() {
  this.showPassword = !this.showPassword;
}

toggleConfirmPasswordVisibility() {
  this.showConfirmPassword = !this.showConfirmPassword;
}

  onRegister() {
    if (this.Password !== this.ConfirmPassword) {
      this.toastr.warning("Passwords do not match");
      return;
    }

    if (!this.UserName || !this.Password || !this.ConfirmPassword) {
      this.toastr.warning("Please fill all fields correctly!");
      return;
    }

    // Validate email format
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(this.UserName)) {
    this.toastr.warning("Please enter a valid email address.");
    return;
  }

   // Validate password strength
   const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;
   // Explanation:
   // - At least 1 lowercase letter
   // - At least 1 uppercase letter
   // - At least 1 digit
   // - Minimum 8 characters
   // - Allows optional special chars (@$!%*?&)
 
   if (!passwordPattern.test(this.Password)) {
    this.toastr.warning("Password must be at least 8 characters and include uppercase, lowercase, and a number.");
     return;
   }

    const request = {
      UserName: this.UserName,
      Password: this.Password,
      ConfirmPassword: this.ConfirmPassword
    };

    this.loading = true;  // start spinner
    this.dataService.registerAdmin(request).subscribe({
      next: (response) => {
        this.UserName = '';
        this.Password = '';
        this.ConfirmPassword = '';
        this.toastr.success("Registration successful!");
        this.loading = false;  // stop spinner on result

      },
      error: (err) => {
        
        this.toastr.error("Registration failed! Please try agin.");      
        this.loading = false;  // stop spinner on error

      }
    });
  }
}
