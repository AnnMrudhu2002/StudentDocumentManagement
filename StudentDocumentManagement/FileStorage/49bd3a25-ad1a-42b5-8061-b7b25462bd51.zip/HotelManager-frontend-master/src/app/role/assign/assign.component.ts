import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-assign',
  standalone: false,
  templateUrl: './assign.component.html',
  styleUrl: './assign.component.css'
})
export class AssignComponent {
  loading: boolean = false;
  roles: any[] = [];
  users: any[] = [];
  selectedUserName: string = '';
  selectedRoleName: string = '';
  selectedUserId: string = '';
  selectedRoleId: string = '';
  assignedRoles: any[] = [];
  submitted: boolean = false;

  constructor(private dataService: DataserviceService, private toastr: ToastrService) {}

 ngOnInit() {
    this.loading=true;
    this.loadRoles();
    this.getUsers();
    this.getAssignedRoles();
    this.loadDropdowns();
    this.loading=false;
    
  }


  loadDropdowns() {
    this.dataService.getUserRoles().subscribe({
      next: data => {
        const allRoles = data.response; 
        console.log('allRoles:', allRoles);
  
        console.log('filtered users:', this.users);
      },
      error: err => console.error('Error fetching assigned roles:', err)
    });
  }

  loadRoles(): void {
    this.loading = true;
    this.dataService.getRoles().subscribe({
      next: (res) => {
        this.roles = res.response;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading roles:', err);
        this.roles = [];
        this.loading = false;
      }
    });
  }

  getUsers(): void {
    this.loading = true;
    this.dataService.getUsers().subscribe({
      next: (data) => {
        this.users = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to load users', err);
        this.loading = false;
      }
    });
  }

  

  getAssignedRoles(): void {
    this.loading = true;
    this.dataService.getUserRoles().subscribe({
      next: (data) => {
        this.assignedRoles = data.response; // Expected: [{userName, roleName}]
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching assigned roles:', err);
        this.loading = false;
      }
    });
  }

  assignRole(): void {
    this.submitted = true;
    if (!this.selectedUserId || !this.selectedRoleId) {
      return;
    }
  
    const rolesPayload = [{ roleName: this.getRoleNameById(this.selectedRoleId), isSelected: true }];
  
    this.dataService.assignUserRole(this.selectedUserId, rolesPayload).subscribe({
      next: (res) => {
        this.toastr.success('Role assigned successfully');
        this.getAssignedRoles(); // refresh table
        this.selectedUserId = '';
        this.selectedRoleId = '';
        this.submitted = false;

      },
      error: (err) => {
        console.error('Assignment error:', err);
        this.submitted = false;

        this.toastr.error('Failed to assign role');
      }
    });
  }
  
  // Helper to get role name from role ID
  getRoleNameById(id: string): string {
    const role = this.roles.find(r => r.id === id);
    return role ? role.name : '';
  }
}
