import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from '../admin/admin.component';
import { AddComponent } from './add/add.component';
import { AssignComponent } from './assign/assign.component';
import { GuestComponent } from './guest/guest.component';
import { RegisteradminComponent } from './registeradmin/registeradmin.component';
import { RoleComponent } from './role.component';

const routes: Routes = [{ path: '', component: RoleComponent },
{path: 'add', component: AddComponent},
{path: 'assign', component: AssignComponent},
{path: 'registeradmin', component: RegisteradminComponent},
{path: 'registerguest', component: GuestComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleRoutingModule { }
