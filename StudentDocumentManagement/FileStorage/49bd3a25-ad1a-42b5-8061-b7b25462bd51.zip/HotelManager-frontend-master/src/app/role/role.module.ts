import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleRoutingModule } from './role-routing.module';
import { RoleComponent } from './role.component';
import { AddComponent } from './add/add.component';
import { AssignComponent } from './assign/assign.component';
import { FormsModule } from '@angular/forms';
import { GuestComponent } from './guest/guest.component';
import { RegisteradminComponent } from './registeradmin/registeradmin.component';


@NgModule({
  declarations: [
    RoleComponent,
    AddComponent,
    AssignComponent,
    GuestComponent,
    RegisteradminComponent
  ],
  imports: [
    CommonModule,
    RoleRoutingModule,
    FormsModule
  ]
})
export class RoleModule { }
