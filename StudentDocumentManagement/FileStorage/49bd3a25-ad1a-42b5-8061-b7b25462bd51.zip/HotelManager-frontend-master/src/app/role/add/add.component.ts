import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-add',
  standalone: false,
  templateUrl: './add.component.html',
  styleUrl: './add.component.css'
})
export class AddComponent {
  role = { name: '' };
  loading: boolean = false;
  roles: any[] = [];
  
  constructor(private dataService: DataserviceService, private toastr: ToastrService) {}

  ngOnInit(){
    this.loadRoles();
  }

 
loadRoles(): void {
  this.loading = true;
  this.dataService.getRoles().subscribe({
    next: (res) => {
      this.roles = res.response; // ✅ correctly assign from 'response'
      this.loading = false;
    },
    error: (err) => {
      console.error('Error loading roles:', err);
      this.roles = [];
      this.loading = false;
    }
  });
}

  onSubmit(roleForm: NgForm): void {
    if (!this.role.name || !this.role.name.trim()) {
      // this.toastr.warning('Role name is required.');
      return;
    }
  
    this.loading = true;
    this.dataService.addRole({ roleName: this.role.name }).subscribe({
      next: (res) => {
        // this.toastr.success(res.response.message);
        this.role.name = '';
        this.toastr.success("Role added successfully");
        roleForm.resetForm(); 
        this.loadRoles(); // optional: refresh list
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.toastr.error("Role name already exists");
        roleForm.resetForm(); 
        // this.toastr.error('Failed to create role.');
        this.loading = false;
      }
    });
  }
}
