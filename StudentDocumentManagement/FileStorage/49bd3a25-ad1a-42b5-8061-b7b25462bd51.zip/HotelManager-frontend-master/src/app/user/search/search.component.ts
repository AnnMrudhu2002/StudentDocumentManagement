import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-search',
  standalone: false,
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {
  filter = {
    checkIn: '',
    checkOut: '',
    adults: 1,
    children: 0
  };
  loading:boolean = false;

  rooms: any[] = [];
  today!: string;
  constructor(
    private bookingService: DataserviceService,
    private router: Router ,
    private toastr: ToastrService
  ) {}


  ngOnInit(): void {
    const currentDate = new Date();
    this.today = currentDate.toISOString().split('T')[0];

    this.loading = true;
    const savedFilter = localStorage.getItem('roomSearchFilter');
    if (savedFilter) {
      this.filter = JSON.parse(savedFilter);
      this.checkAvailability(); // ✅ Re-fetch results on reload
    }
    this.loading = false;
  }
  

  checkAvailability() {
    this.loading=true;
    if (!this.filter.checkIn || !this.filter.checkOut || this.filter.adults < 1) {
      this.toastr.warning('Please fill all required fields correctly');
      return;
    }
    
    localStorage.setItem('roomSearchFilter', JSON.stringify(this.filter));

    this.bookingService.getAvailableRooms(this.filter).subscribe({
      next: (res) => {
        this.rooms = res.map((room: any) => ({
          ...room,
          imagePath: room.imagePaths?.length ? room.imagePaths[0] : 'images/hotel.jpg',
          liked: false
        }));
        this.loadRatings();
        this.loading=false;
      },
      error: () => {
        this.toastr.error('Failed to fetch available rooms.');
        this.loading=false;

      }
    });
  }

  loadRatings() {
    this.rooms.forEach((room) => {
      this.bookingService.getRoomTypeAverageRating(room.roomTypeId).subscribe({
        next: (ratingRes) => {
          room.avgRating = ratingRes.averageRating ?? 0;
        },
        error: () => {
          room.avgRating = 0;
        }
      });
    });
  }

  getDiscountedPrice(rate: number, discount?: number): number {
    if (!discount) return rate;
    return Math.round(rate * (1 - discount / 100));
  }

  getPartialAvailabilityMessage(room: any): string | null {
    const available = room.availableRoomCount;
    const required = room.requiredRoomCount;
  
    if (available != null && required != null && available < required) {
      return `Only ${available} room(s) available, but you require ${required}.`;
    }
  
    return null;
  }
  
  

  // ✅ Navigate to room description with filters as query params
  viewDetails(room: any) {
    this.router.navigate(['/user/book', room.roomTypeId], {
      queryParams: {
        checkIn: this.filter.checkIn,
        checkOut: this.filter.checkOut,
        adults: this.filter.adults,
        children: this.filter.children,
        availableRooms: room.availableRoomCount 
      }
    });
  }
}
