import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookComponent } from './book/book.component';
import { DashboardUserComponent } from './dashboard-user/dashboard-user.component';
import { HistoryComponent } from './history/history.component';
import { ProfileComponent } from './profile/profile.component';
import { SearchComponent } from './search/search.component';
import { UserComponent } from './user.component';

const routes: Routes = [{ path: '', component: UserComponent },
{path: 'dashboard-user', component: DashboardUserComponent},
{ path: 'search', component: SearchComponent },
{ path: 'book/:roomTypeId', component: BookComponent },
{path: 'history', component: HistoryComponent},
{path: 'profile', component: ProfileComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
