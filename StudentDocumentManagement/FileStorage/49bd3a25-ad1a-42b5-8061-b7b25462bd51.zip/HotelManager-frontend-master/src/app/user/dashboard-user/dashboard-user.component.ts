import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-dashboard-user',
  standalone: false,
  templateUrl: './dashboard-user.component.html',
  styleUrl: './dashboard-user.component.css'
})
export class DashboardUserComponent {
  confirmedBookings: any[] = [];
  userId: string = '';
  loading = false;

  constructor(private bookingService: DataserviceService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId') ?? '';
    if (this.userId) {
      this.loadBookings();
    }
  }

  loadBookings(): void {
    this.loading = true;
    this.bookingService.getBookingHistory(this.userId).subscribe({
      next: (data) => {
        this.confirmedBookings = data.filter((b: any)=> b.status === 'Confirmed');
        this.loading = false;
      },
      error: (err) => {
        console.error('Failed to fetch bookings', err);
        this.loading = false;
      }
    });
  }

  canCancel(checkInDate: string): boolean {
    const today = new Date();
    const checkIn = new Date(checkInDate);
  
    // Reset time part to compare only the date
    today.setHours(0, 0, 0, 0);
    checkIn.setHours(0, 0, 0, 0);
  
    const diffInDays = (checkIn.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
    return diffInDays >= 2;
  }

  cancelBooking(bookingId: number): void {
  
    this.bookingService.cancelBooking(bookingId, false).subscribe({
      next: (res) => {
        this.toastr.success('Booking cancelled successfully.');
        this.loadBookings(); // Refresh the list
      },
      error: (err) => {
        this.toastr.error('Failed to cancel the booking.');
      }
    });
  }
  
  
}
