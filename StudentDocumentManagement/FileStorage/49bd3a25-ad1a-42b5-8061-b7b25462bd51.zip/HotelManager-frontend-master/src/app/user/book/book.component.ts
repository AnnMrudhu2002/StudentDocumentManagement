import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';
declare var bootstrap: any;

@Component({
  selector: 'app-book',
  standalone: false,
  templateUrl: './book.component.html',
  styleUrl: './book.component.css'
})
export class BookComponent {
  room: any;
  reviews: any[] = [];
  book: any[] = [];
  bookingDetails: any = null;
  isFavorite = false;
  numberOfRooms = 1;
  averageRating: number | null = null;
  loading: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private roomService: DataserviceService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.loading = true;
    const id = Number(this.route.snapshot.paramMap.get('roomTypeId'));
    const queryParams = this.route.snapshot.queryParams;

    this.roomService.getRoomById(id).subscribe({
      next: (data) => {
        this.room = {
          ...data,
          roomType: data.roomTypeName,
          imagePaths: data.images || []
        };

        // ✅ Store booking form values from query
        this.bookingDetails = {
          checkIn: new Date(queryParams['checkIn']),
          checkOut: new Date(queryParams['checkOut']),
          adults: Number(queryParams['adults']),
          children: Number(queryParams['children']),
          availableRooms: Number(queryParams['availableRooms'])
        };

        this.loadSampleReviews();
        this.loadAverageRating();
        this.loading = false;

      },
      error: (err) => {
        console.error('Failed to load room:', err);
      this.loading = false;

      }
    });
  }

  loadAverageRating(){
    this.loading = true;

    this.roomService.getRoomTypeAverageRating(this.room.roomTypeId).subscribe({
      next: (res) => {
        this.averageRating = res.averageRating;
        this.loading = false;

      },
      error: (err) => {
        console.error('Failed to fetch average rating', err);
        this.loading = false;

      }
    });

  }

  loadSampleReviews() {
    this.roomService.getRoomTypeRatings(this.room.roomTypeId).subscribe({
        next: (reviewData) => {
          this.reviews = reviewData.map((r: any) => ({
            reviewer: r.userName,
            rating: r.stars,
            comment: r.feedback,
            date: new Date(r.ratedOn).toLocaleDateString()
          }));
        },
        error: (err) => {
          console.error('Failed to load reviews:', err);
        }
      });
  }


  get discountedRate(): number {
    const discount = (this.room?.ratePerDay * (this.room?.discountPercentage ?? 0)) / 100;
    return this.room?.ratePerDay - discount;
  }

  get totalRate(): number {
    if (!this.bookingDetails?.checkIn || !this.bookingDetails?.checkOut) return 0;
  
    const checkIn = new Date(this.bookingDetails.checkIn);
    const checkOut = new Date(this.bookingDetails.checkOut);
  
    const millisecondsPerDay = 1000 * 60 * 60 * 24;
    const nights = Math.max(
      1,
      Math.floor((checkOut.getTime() - checkIn.getTime()) / millisecondsPerDay)
    );
  
    const subtotal = this.discountedRate * this.numberOfRooms * nights;
    const tax = subtotal * (this.room?.taxRate / 100);
  
    return subtotal + tax;
  }
  

  get maxAllowedGuests(): number {
    return this.numberOfRooms * (this.room?.maxOccupancy || 0);
  }
  
  get totalGuests(): number {
    return (this.bookingDetails?.adults || 0) + (this.bookingDetails?.children/2 || 0);
  }
  
  get guestOverflow(): boolean {
    return this.totalGuests > this.maxAllowedGuests;
  }
  
  openPreBookingModal() {
    const modalElement = document.getElementById('preBookingModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  
  confirmBooking() {
    const modalElement = document.getElementById('preBookingModal');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    modalInstance.hide();
  
    this.bookNow(); // Now proceed to actual booking
  }



  bookNow() {
    this.loading = true;

    const available = this.bookingDetails.availableRooms;
    if (this.numberOfRooms > available) {
      this.toastr.warning(`Only ${available} room(s) are available for your selected dates.
       Please adjust the number of rooms or choose different dates to proceed.`);

      return;
    }

    if (this.totalGuests > this.maxAllowedGuests) {
      this.toastr.warning(`Total guests exceed maximum occupancy for ${this.numberOfRooms} room(s). Allowed: ${this.maxAllowedGuests}`);
      return;

      
    }

    const payload = {
      checkIn: this.bookingDetails.checkIn,
      checkOut: this.bookingDetails.checkOut,
      adults: this.bookingDetails.adults,
      children: this.bookingDetails.children,
      userId: localStorage.getItem('userId'),
      roomTypeId: this.room.roomTypeId,
      requestedRooms: this.numberOfRooms
    };

    this.roomService.bookRoom(payload).subscribe({
      next: (res) => {
        this.bookingDetails = {
          ...this.bookingDetails, // keep dates, guests
          bookingId: res.bookingId,
          bookingDate: new Date(),
          roomCount: res.roomCount,
          baseAmount: res.baseAmount,
          discountedAmount: res.discountedAmount,
          taxAmount: res.taxAmount,
          finalAmount: res.finalAmount
        };
         // ✅ Clear saved filters from localStorage after successful booking
    localStorage.removeItem('roomSearchFilter');
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    this.loading = false;


      },
      error: (err) => {
        this.toastr.error('Booking failed. Please try again later.');
        console.error(err);
        this.loading = false;

      }
    });
  }


 
  
  


}
