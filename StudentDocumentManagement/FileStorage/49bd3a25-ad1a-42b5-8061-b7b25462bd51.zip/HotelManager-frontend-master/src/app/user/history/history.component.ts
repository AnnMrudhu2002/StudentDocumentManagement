import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-history',
  standalone: false,
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent {
  userId = '';
  bookings: any[] = [];
  ratingForms: { [bookingId: number]: FormGroup } = {};
  loading: boolean = false;
  submittedRatings: { [bookingId: number]: boolean } = {};


  constructor(private bookingService: DataserviceService, private fb: FormBuilder, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.loading = true;
    this.userId = this.getUserIdFromStorage();
    this.getBookingHistory();
    this.loading = false;

  }

  getUserIdFromStorage(): string {
    const id = localStorage.getItem('userId');
    return id ?? '';
  }

  getBookingHistory(): void {
    if (!this.userId) {
      console.error('User ID not found');
      this.loading = false;
      return;
    }

    this.bookingService.getBookingHistory(this.userId).subscribe({
      next: (data) => {
        this.bookings = data;
        this.loading = false;
        // Initialize rating forms for each booking
        this.bookings.forEach((booking: any) => {
          this.ratingForms[booking.bookingId] = this.fb.group({
            roomTypeId: [booking.rooms[0]?.roomTypeId || 0],
            stars: [null],
            feedback: ['']
          });
        });
      },
      error: (err) => {
        console.error('Error fetching booking history', err);
        this.loading = false;
      }
    });
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString();
  }

  submitRating(bookingId: number): void {
    const form = this.ratingForms[bookingId];
    const payload = {
      bookingId: bookingId,
      roomTypeId: form.value.roomTypeId,
      stars: form.value.stars,
      feedback: form.value.feedback
    };
    console.log("Submitting rating:", payload);  // <-- Add this lin

    this.bookingService.submitRating(payload).subscribe({
      next: () => {
        this.toastr.success('Rating submitted!');
        this.submittedRatings[bookingId] = true; // Mark as submitted
      },
      error: () => this.toastr.error('Failed to submit rating')
    });
  }
}
