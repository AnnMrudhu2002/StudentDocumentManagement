import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-profile',
  standalone: false,
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  userProfileForm!: FormGroup;
  isEditing = false;
  userId = localStorage.getItem('userId') ?? '';

  constructor(private userService: DataserviceService, private fb: FormBuilder, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.getProfile();
  }

  allowLettersOnly(event: KeyboardEvent) {
    const char = String.fromCharCode(event.keyCode || event.which);
    const isLetter = /^[a-zA-Z]$/.test(char);
  
    if (!isLetter) {
      event.preventDefault();
    }
  }

  allowNumbersOnly(event: KeyboardEvent) {
    const char = String.fromCharCode(event.keyCode || event.which);
    const isNumber = /^[0-9]$/.test(char);
  
    if (!isNumber) {
      event.preventDefault();
    }
  }
  
  

  getProfile() {
    if (this.userId) {
      this.userService.getUserProfile(this.userId).subscribe({
        next: (data) => {
          this.userProfileForm = this.fb.group({
            id: [data.id],
            firstName: [data.firstName, Validators.required],
            lastName: [data.lastName, Validators.required],
            email: [{ value: data.email, disabled: true }, [Validators.required, Validators.email]],
            phoneNumber: [data.phoneNumber, Validators.required],
            address: [data.address, Validators.required],
            city: [data.city, Validators.required],
            state: [data.state, Validators.required],
            age: [data.age, Validators.required]
          });
        },
        error: (err) => {
          console.error('Failed to fetch user profile', err);
        }
      });
    }
  }
  

  onEditProfile() {
    this.isEditing = true;
  }

  onCancelEdit() {
    this.isEditing = false;
    this.getProfile(); // reset form
  }

  onSaveProfile() {
    if (this.userProfileForm.invalid) {
      this.userProfileForm.markAllAsTouched(); // highlight errors
      return;
    }
  
    this.userService.updateUserProfile(this.userProfileForm.value).subscribe({
      next: () => {
        this.toastr.success('Profile updated successfully!');
        this.isEditing = false;
      },
      error: (err) => {
        console.error('Failed to update profile', err);
        this.toastr.error("Failed to update profile")
      }
    });
  }
  
}
