import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/footer/footer.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { SidebaruserComponent } from './shared/sidebaruser/sidebaruser.component';
import { LayoutUserComponent } from './shared/layout-user/layout-user.component';
import { RoomsComponent } from './rooms/rooms.component';
import { RoomDescriptionComponent } from './room-description/room-description.component';
import { HttpClientModule, provideHttpClient, withInterceptors } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NavbarHomeComponent } from './shared/navbar-home/navbar-home.component';
import { LayoutAdminComponent } from './shared/layout-admin/layout-admin.component';
import { SidebaradminComponent } from './shared/sidebaradmin/sidebaradmin.component';
import { Footer2Component } from './shared/footer-2/footer-2.component';
import { authInterceptor } from './auth.interceptor';
import { RoomlistComponent } from './roomlist/roomlist.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    NavbarComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    SidebaruserComponent,
    LayoutUserComponent,
    RoomsComponent,
    RoomDescriptionComponent,
    NavbarHomeComponent,
    LayoutAdminComponent,
    SidebaradminComponent,
    Footer2Component,
    RoomlistComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    CommonModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      positionClass: 'toast-position',  // position
      timeOut: 3000,                        // 3 seconds default timeout
      closeButton: false,
      progressBar: false,
      preventDuplicates: true,
      toastClass: 'ngx-toastr custom-toast'
    })

  ],
  providers: [   provideHttpClient(
    withInterceptors([authInterceptor])  
  )],
  bootstrap: [AppComponent]
})
export class AppModule { }
