import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  FirstName = '';
  LastName = '';
  Age: any = '';
  Address = '';
  City = '';
  State = '';
  Phone = '';
  UserName = '';
  Password = '';
  ConfirmPassword = '';
  showPassword = false;
  showConfirmPassword = false;
  loading = false;
  submitted = false;

  

  constructor(private dataService: DataserviceService, private toastr: ToastrService) { }

 
togglePasswordVisibility() {
  this.showPassword = !this.showPassword;
}

toggleConfirmPasswordVisibility() {
  this.showConfirmPassword = !this.showConfirmPassword;
}

allowLettersOnly(event: KeyboardEvent): void {
  const char = event.key;
  const regex = /^[a-zA-Z]+$/;

  if (!regex.test(char)) {
    event.preventDefault();
  }
}

allowNumbersOnly(event: KeyboardEvent): void {
  const char = event.key;
  const regex = /^[0-9]$/;

  if (!regex.test(char)) {
    event.preventDefault();
  }
}


  onRegister() {
    this.submitted = true;

    const ageValue = Number(this.Age);

    if (!ageValue || ageValue <= 0) {
      return; // Invalid age
    }
  
    this.Age = ageValue;

    if (this.Password !== this.ConfirmPassword) {
      this.toastr.warning("Passwords do not match");
      return;
    }

    if (!this.UserName || !this.Password || !this.ConfirmPassword || !this.FirstName 
      || !this.LastName || !this.Age || !this.Address || !this.City || !this.State || !this.Phone) {
      this.toastr.warning("Please fill all fields correctly!");
      return;
    }

    // Validate email format
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(this.UserName)) {
    this.toastr.warning("Please enter a valid email address.");
    return;
  }

   // Validate password strength
   const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;
   // Explanation:
   // - At least 1 lowercase letter
   // - At least 1 uppercase letter
   // - At least 1 digit
   // - Minimum 8 characters
   // - Allows optional special chars (@$!%*?&)
 
   if (!passwordPattern.test(this.Password)) {
    this.toastr.warning("Password must be at least 8 characters and include uppercase, lowercase, and a number.");
     return;
   }

   const request = {
    UserName: this.UserName,
    Password: this.Password,
    ConfirmPassword: this.ConfirmPassword,
    FirstName: this.FirstName,
    LastName: this.LastName,
    Age: this.Age,
    Address: this.Address,
    City: this.City,
    State: this.State,
    PhoneNumber: this.Phone
  };

  
  

    this.loading = true;  // start spinner
    this.dataService.register(request).subscribe({
      next: (response) => {
        this.toastr.success("Registration successful!");
        this.loading = false;  // stop spinner on result

      },
      error: (err) => {
        
        this.toastr.error("Registration failed! Please try agin.");      
        this.loading = false;  // stop spinner on error

      }
    });
  }
}
