import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddRoomComponent } from './add-room/add-room.component';
import { AdminComponent } from './admin.component';
import { CheckinComponent } from './checkin/checkin.component';
import { CheckinoutComponent } from './checkinout/checkinout.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { OfflinebookingComponent } from './offlinebooking/offlinebooking.component';
import { RoomtypesComponent } from './roomtypes/roomtypes.component';

const routes: Routes = [{ path: '', component: AdminComponent },
{path: 'dashboard-admin', component: DashboardAdminComponent},
{path: 'addroom', component: AddRoomComponent},
{path: 'roomtypes', component: RoomtypesComponent},
{path: 'checkin', component: CheckinComponent},
{path: 'checkout', component: CheckoutComponent},
{path: 'checkinout', component: CheckinoutComponent},
{path: 'offlinebooking', component: OfflinebookingComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
