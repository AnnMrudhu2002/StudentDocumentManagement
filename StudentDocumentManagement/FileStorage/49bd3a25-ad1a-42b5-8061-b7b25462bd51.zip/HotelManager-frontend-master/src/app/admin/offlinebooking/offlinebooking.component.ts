import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-offlinebooking',
  standalone: false,
  templateUrl: './offlinebooking.component.html',
  styleUrl: './offlinebooking.component.css'
})
export class OfflinebookingComponent {
  bookForm!: FormGroup;
  roomTypes: any[] = [];

  constructor(private fb: FormBuilder, private dataService: DataserviceService, private Toastr: ToastrService) {}

  ngOnInit(): void {
    this.bookForm = this.fb.group({
      userEmail: ['', [Validators.required, Validators.email]],
      roomTypeId: [null, Validators.required],
      requestedRooms: [1, [Validators.required, Validators.min(1)]],
      checkIn: [null, Validators.required],
      checkOut: [null, Validators.required],
      adults: [1, [Validators.required, Validators.min(1)]],
      children: [0, [Validators.required, Validators.min(0)]],
    });

    this.getRoomTypes();
  }

  getRoomTypes(): void {
    this.dataService.getRoomTypes().subscribe({
      next: (data) => this.roomTypes = data,
      error: () => alert('Failed to load room types')
    });
  }

  onSubmit(): void {
    if (this.bookForm.invalid) return;

    const payload = this.bookForm.value;
    this.dataService.bookRoom(payload).subscribe({
      next: (res) => {
        alert(res.message || 'Booking successful!');
        this.bookForm.reset();
      },
      error: (err) => {
        alert(err.error?.message || 'Booking failed.');
      }
    });
  }
}
