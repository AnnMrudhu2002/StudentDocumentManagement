import { Component } from '@angular/core';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-checkinout',
  standalone: false,
  templateUrl: './checkinout.component.html',
  styleUrl: './checkinout.component.css'
})
export class CheckinoutComponent {
  bookings: any[] = [];
  loading: boolean = false;
  error: string = '';

  roomStatuses: any[] = [];
  roomTypes: any[] = [];
  users: any[] = [];

  search: any = {
    bookingId: '',
    statusId: '',
    roomTypeId: '',
    userId: ''
  };

  constructor(private bookingService: DataserviceService) {}

  ngOnInit(): void {
    this.loadDropdownData();
    this.loadBookings();
  }

  loadDropdownData() {
    this.bookingService.getRoomStatuses().subscribe(data => this.roomStatuses = data);
    this.bookingService.getRoomTypes().subscribe(data => this.roomTypes = data);
    this.bookingService.getUsers().subscribe(data => this.users = data);
  }

  loadBookings() {
    this.loading = true;
    this.bookingService.getAllBookings().subscribe({
      next: (data) => {
        this.bookings = data.reverse();
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load bookings.';
        this.loading = false;
      }
    });
  }

  onSearch() {
    this.loading = true;
    this.bookingService.getAllBookingsBySearch(this.search).subscribe({
      next: (data) => {
        this.bookings = data.reverse();
        this.loading = false;
      },
      error: () => {
        this.error = 'Search failed.';
        this.loading = false;
      }
    });
  }

  resetSearch() {
    this.search = {
      bookingId: '',
      customerName: '',
      status: '',
      roomType: ''
    };
    this.loadBookings();
  }
 

}
