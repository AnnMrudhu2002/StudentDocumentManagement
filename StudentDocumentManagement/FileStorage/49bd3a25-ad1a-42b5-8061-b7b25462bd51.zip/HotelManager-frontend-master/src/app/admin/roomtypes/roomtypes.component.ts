import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-roomtypes',
  standalone: false,
  templateUrl: './roomtypes.component.html',
  styleUrl: './roomtypes.component.css'
})
export class RoomtypesComponent {
  roomTypeForm!: FormGroup;
  amenitiesList: any[] = [];  // will be fetched from API
  roomTypes: any[] = [];
  selectedRoomTypeId: number | null = null;
  errorMessage: string = '';


  constructor(private fb: FormBuilder, private roomService: DataserviceService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.roomTypeForm = this.fb.group({
      roomTypeName: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[a-zA-Z\s]+$/),
          Validators.maxLength(25)
        ]
      ],
      description: ['', Validators.required],
      imagePaths: this.fb.array([this.fb.control('', Validators.required)]),
      maxOccupancy: [
        null,
        [Validators.required, Validators.min(1), Validators.max(10)]
      ],
      ratePerDay: [
        null,
        [Validators.required, Validators.min(100)]
      ],
      taxRate: [
        null,
        [Validators.required, Validators.min(0), Validators.max(100)]
      ],
      discountPercentage: [
        null,
        [Validators.required, Validators.min(0), Validators.max(100)]
      ],
      
      amenityIds: this.fb.array([], Validators.required)
    });

    this.getAmenities();
    this.getRoomTypes();
  }

  get imagePaths() {
    return this.roomTypeForm.get('imagePaths') as FormArray;
  }

  addImagePath() {
    this.imagePaths.push(this.fb.control('', Validators.required));
  }

  removeImagePath(index: number) {
    this.imagePaths.removeAt(index);
  }

  onAmenityChange(event: any, amenityId: number) {
    const amenities = this.roomTypeForm.get('amenityIds') as FormArray;
    if (event.target.checked) {
      amenities.push(this.fb.control(amenityId));
    } else {
      const index = amenities.controls.findIndex(x => x.value === amenityId);
      if (index >= 0) {
        amenities.removeAt(index);
      }
    }
  }

  allowOnlyNumbers(event: KeyboardEvent): void {
    const charCode = event.key;
    if (!/^\d$/.test(charCode)) {
      event.preventDefault();
    }
  }

  allowOnlyLetters(event: KeyboardEvent): void {
  const charCode = event.key;
  if (!/^[a-zA-Z\s]$/.test(charCode)) {
    event.preventDefault();
  }
}

  

  resetForm() {
    this.roomTypeForm = this.fb.group({
      roomTypeName: [
        '',
        [
          Validators.required,
          Validators.pattern(/^[a-zA-Z\s]+$/),
          Validators.maxLength(25)
        ]
      ],
      description: ['', Validators.required],
      imagePaths: this.fb.array([this.fb.control('', Validators.required)]),
      maxOccupancy: [
        null,
        [Validators.required, Validators.min(1), Validators.max(10)]
      ],
      ratePerDay: [
        null,
        [Validators.required, Validators.min(100)]
      ],
      taxRate: [
        null,
        [Validators.required, Validators.min(0), Validators.max(100)]
      ],
      discountPercentage: [
        null,
        [Validators.required, Validators.min(0), Validators.max(100)]
      ],
      amenityIds: this.fb.array([], Validators.required)
    });
  
    this.selectedRoomTypeId = null;
  }
  
  
  isAmenitySelected(amenityId: number): boolean {
    const amenities = this.roomTypeForm.get('amenityIds') as FormArray;
    return amenities.controls.some(control => control.value === amenityId);
  }
  

  onSubmit() {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Trigger validation for amenities if untouched
const amenities = this.roomTypeForm.get('amenityIds');
if (amenities && amenities.invalid) {
  amenities.markAsTouched();
  amenities.updateValueAndValidity();
}


    if (this.roomTypeForm.valid) {
      const formData = this.roomTypeForm.value;
      formData.amenityIds = formData.amenityIds.filter((id: number | null) => id !== null);
      console.log('Update data:', formData);
      if (this.selectedRoomTypeId) {
        // Editing
        this.roomService.updateRoomType(this.selectedRoomTypeId, formData).subscribe({
          next: () => {
            this.errorMessage = ''; 
            this.resetForm();
            this.getRoomTypes();
            this.toastr.success("Room type edited successfully");
            
          },
          error: err => {this.errorMessage = err.error?.message || 'An error occurred while adding the room type';
          this.toastr.error('An error occurred while adding the room type')}
        });
      } else {
        // Adding new
        this.roomService.addRoomType(formData).subscribe({
          next: () => {
            this.errorMessage = ''; 
            this.resetForm();
            this.getRoomTypes();
            this.toastr.success("Room type added successfully");

          },
          error: err => {this.errorMessage = err.error?.message || 'Room type already exists';
          this.resetForm();
        }

        });
      }
    }
  }


  onEdit(room: any) {
  window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });

    this.selectedRoomTypeId = room.roomTypeId;

    // Scroll to top

  
    // Prepare image form controls
    const imageControls = room.imagePaths.map((img: string) =>
      this.fb.control(img, Validators.required)
    );
  
    // Prepare amenity form controls (assuming room.amenities is array of IDs or objects with amenityId)
    const amenityControls = (room.amenities || []).map((a: any) =>
      this.fb.control(typeof a === 'number' ? a : a.amenityId)
    );
  
    // Patch form values
    this.roomTypeForm.patchValue({
      roomTypeName: room.roomTypeName,
      description: room.description,
      maxOccupancy: room.maxOccupancy,
      ratePerDay: room.ratePerDay,
      taxRate: room.taxRate,
      discountPercentage: room.discountPercentage
    });
    
  
    // Set imagePaths and amenityIds arrays
    this.roomTypeForm.setControl('imagePaths', this.fb.array(imageControls));
    this.roomTypeForm.setControl('amenityIds', this.fb.array(amenityControls));
  }
  
  
  

  getRoomTypes() {
    this.roomService.getRoomTypes().subscribe({
      next: data => this.roomTypes = data,
      error: err => console.error(err)
    });
  }

  getAmenities() {
    this.roomService.getAmenities().subscribe({
      next: data => this.amenitiesList = data,
      error: err => console.error('Failed to load amenities', err)
    });
  }
}
