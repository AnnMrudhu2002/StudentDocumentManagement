import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-checkin',
  standalone: false,
  templateUrl: './checkin.component.html',
  styleUrl: './checkin.component.css'
})
export class CheckinComponent {
  bookings: any[] = [];
  loading: boolean = false;
  error: string = '';

  constructor(private bookingService: DataserviceService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.loadPendingCheckIns();
  }

  loadPendingCheckIns() {
    this.loading = true;
    this.bookingService.getAllBookings().subscribe({
      next: (data) => {
        // Filter only bookings where actualCheckIn is not yet done
        this.bookings = data.filter((b: any) => !b.actualCheckIn && b.statusName !== "Cancelled");
        console.log('Filtered bookings:', this.bookings);
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load bookings.';
        this.loading = false;
      }
    });
  }

  checkIn(bookingId: number) {
    this.bookingService.checkIn(bookingId).subscribe({
      next: (res) => {
        this.toastr.success("Successfuly Checked In");
        this.loadPendingCheckIns(); // refresh list
      },
      error: (err) => {
        this.toastr.error('Check-in failed.');
      }
    });
  }

  cancelBooking(bookingId: number) {
      this.bookingService.cancelBooking(bookingId, true).subscribe({
        next: (res) => {
          this.toastr.success('Booking cancelled');
          this.loadPendingCheckIns(); // Refresh the list
        },
        error: (err) => {
          this.toastr.error('Failed to cancel booking');
        }
      });
    
  }
  
}
