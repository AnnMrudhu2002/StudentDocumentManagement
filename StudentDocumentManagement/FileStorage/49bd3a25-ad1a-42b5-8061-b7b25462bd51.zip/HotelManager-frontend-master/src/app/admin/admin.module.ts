import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AddRoomComponent } from './add-room/add-room.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoomtypesComponent } from './roomtypes/roomtypes.component';
import { CheckinoutComponent } from './checkinout/checkinout.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { CheckinComponent } from './checkin/checkin.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { OfflinebookingComponent } from './offlinebooking/offlinebooking.component';


@NgModule({
  declarations: [
    AdminComponent,
    AddRoomComponent,
    RoomtypesComponent,
    CheckinoutComponent,
    DashboardAdminComponent,
    CheckinComponent,
    CheckoutComponent,
    OfflinebookingComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminModule { }
