import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-add-room',
  standalone: false,
  templateUrl: './add-room.component.html',
  styleUrl: './add-room.component.css'
})
export class AddRoomComponent {
  addRoomForm: FormGroup;
  roomTypes: any[] = [];
  statusOptions: any[] = [];
  roomList: any[] = []; 
  errorMessage: string = '';
  statusTouchedMap: { [roomId: number]: boolean } = {};
  loading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private roomService: DataserviceService,
    private toastr: ToastrService
  ) {
    this.addRoomForm = this.fb.group({
      roomNumber: ['',
        
        [
          Validators.required,
          Validators.pattern(/^\d+$/), // digits only
        ]
      ],
      floor: ['',
        
      [
        Validators.required,
        Validators.pattern(/^\d+$/), // digits only
      ]
    ],
      roomTypeId: [null, Validators.required],
      statusName: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loading = true;
    this.fetchRoomTypes();
    this.fetchStatuses();
    this.fetchRooms();
    this.loading = false;


  }

  fetchRoomTypes() {
    this.roomService.getRoomTypes().subscribe({
      next: data => this.roomTypes = data,
      error: err => console.error('Error fetching room types:', err)
    });
  }

  fetchRooms() {
    this.roomService.getAllRooms().subscribe({
      next: data => this.roomList = data,
      error: err => console.error('Error fetching room list:', err)
    });
  }


  fetchStatuses() {
    this.roomService.getRoomStatuses().subscribe({
      next: data => this.statusOptions = data,
      error: err => console.error('Error fetching status list:', err)
    });
  }


  allowOnlyDigits(event: KeyboardEvent): void {
    const charCode = event.key;
    if (!/^\d$/.test(charCode)) {
      event.preventDefault();
    }
  }

  
  onSubmit() {
    if (this.addRoomForm.invalid) return;

    const formData = this.addRoomForm.value;
    this.roomService.addRoom(formData).subscribe({
      next: res => {
        this.errorMessage = '';
        this.toastr.success('Room added successfully');
        this.addRoomForm.reset();
        this.fetchRooms();

      },
      error: err => {
        this.errorMessage = err.error?.message || 'An error occurred while adding the room.';
        this.addRoomForm.reset();
        this.toastr.error('Error adding room');
      }
    });
  }

  changeRoomStatus(room: any) {
    this.statusTouchedMap[room.roomId] = true;
    if (!room.newStatus) {
      return;
    }
  
    this.roomService.updateRoomStatus(room.roomId, room.newStatus).subscribe({
      next: res => {
        console.log(res);
        this.fetchRooms(); // Refresh room list
        this.statusTouchedMap[room.roomId] = false; // Clear touched state
        this.toastr.success("Status updated successfully")
      },
      error: err => {
        console.error('Failed to update status:', err);
        this.toastr.error("Error updating room status");
      }
    });
  }
  

  

}
