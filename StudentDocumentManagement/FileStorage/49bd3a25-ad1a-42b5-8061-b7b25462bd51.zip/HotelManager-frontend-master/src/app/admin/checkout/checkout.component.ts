import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../../dataservice.service';

@Component({
  selector: 'app-checkout',
  standalone: false,
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {
  bookings: any[] = [];
  loading = false;
  error = '';

  constructor(private bookingService: DataserviceService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.loadCheckedInRooms();
  }

  loadCheckedInRooms() {
    this.loading = true;
    this.bookingService.getAllBookings().subscribe({
      next: (data) => {
        if (!Array.isArray(data)) {
          this.error = 'Invalid data received.';
          this.loading = false;
          return;
        }
  
        // Keep grouped bookings (like check-in)
        this.bookings = data.filter((b: any) => b.actualCheckIn && !b.actualCheckOut);
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load checked-in bookings.';
        this.loading = false;
      }
    });
  }
  
  previewFinalAmount(bookingId: number) {
    this.bookingService.previewAmount(bookingId).subscribe({
      next: (response) => {
        const booking = this.bookings.find(b => b.bookingId === bookingId);
        if (booking) {
          booking.finalAmount = response.amount ?? '---';
          booking.previewed = true;
          console.log(response);
        }
      },
      error: () => {
        this.toastr.error('Failed to preview final amount');
      }
    });
  }
  

  
  checkOut(bookingId: number, isPaymentDone: boolean) {
 

    if (!isPaymentDone) {
      this.toastr.warning('Please confirm payment before checking out');
      return;
    }

    
  
    this.bookingService.checkOut(bookingId, isPaymentDone).subscribe({
      next: () => {
        this.toastr.success('Checked out successfully');
        this.loadCheckedInRooms();
      },
      error: (err) => {
        this.toastr.error('Checkout failed');
      }
    });
  }
  
}
