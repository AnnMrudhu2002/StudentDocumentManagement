import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { authGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RoomDescriptionComponent } from './room-description/room-description.component';
import { RoomlistComponent } from './roomlist/roomlist.component';
import { RoomsComponent } from './rooms/rooms.component';
import { LayoutAdminComponent } from './shared/layout-admin/layout-admin.component';
import { LayoutUserComponent } from './shared/layout-user/layout-user.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [{ path: '', redirectTo: 'home', pathMatch: 'full' },
{ path: 'home', component: HomeComponent },
{path: 'roomlist', component: RoomlistComponent},
{ path: 'login', component: LoginComponent },
{ path: 'signup', component: SignupComponent },

{
  path: '', component: LayoutUserComponent, canActivate: [authGuard],
  children: [
    { path: 'user', loadChildren: () => import('./user/user.module').then(m => m.UserModule) }
  ]
},
{
  path: '', component: LayoutAdminComponent, canActivate: [authGuard],
  children: [
    { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule) },
    { path: 'role', loadChildren: () => import('./role/role.module').then(m => m.RoleModule) }

  ]
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
