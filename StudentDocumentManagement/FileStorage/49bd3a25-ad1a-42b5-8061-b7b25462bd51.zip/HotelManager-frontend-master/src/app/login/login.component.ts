import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  UserName = '';
  Password = '';
  loading: boolean = false;  //loading flag
  assignedRoles: any[] = [];
  showPassword: boolean = false;
  submitted = false;



  constructor(
    private router: Router, private dataService: DataserviceService, private toastr: ToastrService) { }

     togglePasswordVisibility(): void {
      this.showPassword = !this.showPassword;
     }
    
  


     onLogin() {
      this.submitted = true;
      if (!this.UserName || !this.Password) {
        this.toastr.warning("Please fill all fields correctly!");
        return;
      }
    
      const loginRequest = {
        userName: this.UserName,
        password: this.Password,
      };
    
      this.loading = true;
    
      this.dataService.authenticate(loginRequest).subscribe({
        next: (res: any) => {
          const user = res;
    
          if (!user) {
            this.toastr.error("Username does not exist!");
            this.loading = false;
            return;
          }
    
          this.toastr.success("Login successful. Welcome Back!");
    
          // Save data to localStorage
          localStorage.setItem('userId', user.id);
          localStorage.setItem('userName', user.userName);
          localStorage.setItem('role', JSON.stringify(user.role)); // Save roles array
          localStorage.setItem('token', user.token);
          console.log('Login response:', user);
          
          // Check for 'Admin' role
          const isAdmin = user.role.includes('Admin');
    
          this.loading = false;
    
          if (isAdmin) {
            this.router.navigate(['/admin/dashboard-admin']);
          } else {
            this.router.navigate(['/user/dashboard-user']);
          }
        },
        error: (err) => {
          this.toastr.error("Login failed! Please try again.");
          this.loading = false;
          console.error("Login error:", err);
        }
      });
    }
    
    
}
