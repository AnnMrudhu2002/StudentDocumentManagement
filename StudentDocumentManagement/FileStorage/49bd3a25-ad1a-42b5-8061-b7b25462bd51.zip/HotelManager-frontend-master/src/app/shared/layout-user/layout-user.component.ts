import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-user',
  standalone: false,
  templateUrl: './layout-user.component.html',
  styleUrl: './layout-user.component.css'
})
export class LayoutUserComponent {
  sidebarCollapsed = false;

  onSidebarToggled(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }
}
