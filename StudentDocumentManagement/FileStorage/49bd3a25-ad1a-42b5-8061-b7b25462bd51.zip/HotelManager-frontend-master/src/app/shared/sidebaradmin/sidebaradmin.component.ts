import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-sidebaradmin',
  standalone: false,
  templateUrl: './sidebaradmin.component.html',
  styleUrl: './sidebaradmin.component.css'
})
export class SidebaradminComponent {
  collapsed = false;
  showProjectSubmenu = false;
  showTaskSubmenu = false;
  showRoleSubmenu = false;

  constructor(private authService: AuthService, private router: Router) {}

  onLogout() {
    this.authService.logout(); // This clears localStorage and navigates to login
  }

  @Output() toggleSidebar = new EventEmitter<void>();

  toggleCollapse(): void {
    this.toggleSidebar.emit();
  }

  
}
