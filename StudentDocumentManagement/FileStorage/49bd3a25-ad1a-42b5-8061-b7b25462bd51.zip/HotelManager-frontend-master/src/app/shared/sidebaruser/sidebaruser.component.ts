import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-sidebaruser',
  standalone: false,
  templateUrl: './sidebaruser.component.html',
  styleUrl: './sidebaruser.component.css'
})
export class SidebaruserComponent {
  collapsed = false;
  showProjectSubmenu = false;
  showTaskSubmenu = false;
  showRoleSubmenu = false;

  constructor(private authService: AuthService, private router: Router) {}

  onLogout() {
     localStorage.removeItem('roomSearchFilter');
    this.authService.logout(); // This clears localStorage and navigates to login
  }

  @Output() toggleSidebar = new EventEmitter<void>();

  toggleCollapse(): void {
    this.toggleSidebar.emit();
  }

}
