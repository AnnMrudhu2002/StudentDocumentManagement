import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-2',
  standalone: false,
  templateUrl: './footer-2.component.html',
  styleUrl: './footer-2.component.css'
})
export class Footer2Component {

}
