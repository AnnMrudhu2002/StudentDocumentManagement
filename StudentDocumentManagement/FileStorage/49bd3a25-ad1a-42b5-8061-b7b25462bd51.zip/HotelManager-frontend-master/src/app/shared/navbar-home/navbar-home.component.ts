import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar-home',
  standalone: false,
  templateUrl: './navbar-home.component.html',
  styleUrl: './navbar-home.component.css'
})
export class NavbarHomeComponent {

}
