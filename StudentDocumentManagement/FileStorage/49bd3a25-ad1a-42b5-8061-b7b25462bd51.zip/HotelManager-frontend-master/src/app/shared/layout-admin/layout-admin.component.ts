import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-admin',
  standalone: false,
  templateUrl: './layout-admin.component.html',
  styleUrl: './layout-admin.component.css'
})
export class LayoutAdminComponent {
  sidebarCollapsed = false;

  onSidebarToggled(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }
}
